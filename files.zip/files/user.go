package models

import (
	"time"
)

// User represents an application user.
// Matches the `users` table created in migrations/001_create_users.sql
type User struct {
	ID          string     `db:"id"           json:"id"`
	Email       *string    `db:"email"         json:"email,omitempty"`
	Phone       *string    `db:"phone"         json:"phone,omitempty"`
	Verified    bool       `db:"verified"      json:"verified"`
	CreatedAt   time.Time  `db:"created_at"    json:"created_at"`
	UpdatedAt   time.Time  `db:"updated_at"    json:"updated_at"`
	LastLoginAt *time.Time `db:"last_login_at" json:"last_login_at,omitempty"`
}

// RefreshToken stores issued refresh tokens so they can be revoked.
type RefreshToken struct {
	ID        string    `db:"id"`
	UserID    string    `db:"user_id"`
	TokenHash string    `db:"token_hash"` // SHA-256 of the raw token
	ExpiresAt time.Time `db:"expires_at"`
	CreatedAt time.Time `db:"created_at"`
}
