package db

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/jmoiron/sqlx"

	"yourmodule/models" // Replace with your actual module path
)

// UserRepository handles all user-related database operations.
type UserRepository struct {
	db *sqlx.DB
}

func NewUserRepository(db *sqlx.DB) *UserRepository {
	return &UserRepository{db: db}
}

// FindByEmail returns the user with the given e-mail, or nil if not found.
func (r *UserRepository) FindByEmail(ctx context.Context, email string) (*models.User, error) {
	var u models.User
	err := r.db.GetContext(ctx, &u, `SELECT * FROM users WHERE email = $1 LIMIT 1`, email)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("find user by email: %w", err)
	}
	return &u, nil
}

// FindByPhone returns the user with the given E.164 phone number, or nil if not found.
func (r *UserRepository) FindByPhone(ctx context.Context, phone string) (*models.User, error) {
	var u models.User
	err := r.db.GetContext(ctx, &u, `SELECT * FROM users WHERE phone = $1 LIMIT 1`, phone)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("find user by phone: %w", err)
	}
	return &u, nil
}

// FindByID returns the user with the given UUID, or nil if not found.
func (r *UserRepository) FindByID(ctx context.Context, id string) (*models.User, error) {
	var u models.User
	err := r.db.GetContext(ctx, &u, `SELECT * FROM users WHERE id = $1 LIMIT 1`, id)
	if errors.Is(err, sql.ErrNoRows) {
		return nil, nil
	}
	if err != nil {
		return nil, fmt.Errorf("find user by id: %w", err)
	}
	return &u, nil
}

// UpsertByEmail creates the user if they don't exist, marks them verified, and
// updates last_login_at. Returns the final user record.
func (r *UserRepository) UpsertByEmail(ctx context.Context, email string) (*models.User, error) {
	const q = `
		INSERT INTO users (email, verified, last_login_at)
		VALUES ($1, true, NOW())
		ON CONFLICT (email) DO UPDATE
		  SET verified      = true,
		      last_login_at = NOW(),
		      updated_at    = NOW()
		RETURNING *`
	var u models.User
	if err := r.db.GetContext(ctx, &u, q, email); err != nil {
		return nil, fmt.Errorf("upsert user by email: %w", err)
	}
	return &u, nil
}

// UpsertByPhone creates the user if they don't exist, marks them verified, and
// updates last_login_at. Returns the final user record.
func (r *UserRepository) UpsertByPhone(ctx context.Context, phone string) (*models.User, error) {
	const q = `
		INSERT INTO users (phone, verified, last_login_at)
		VALUES ($1, true, NOW())
		ON CONFLICT (phone) DO UPDATE
		  SET verified      = true,
		      last_login_at = NOW(),
		      updated_at    = NOW()
		RETURNING *`
	var u models.User
	if err := r.db.GetContext(ctx, &u, q, phone); err != nil {
		return nil, fmt.Errorf("upsert user by phone: %w", err)
	}
	return &u, nil
}

// TouchLastLogin updates last_login_at for the given user.
func (r *UserRepository) TouchLastLogin(ctx context.Context, userID string) error {
	now := time.Now()
	_, err := r.db.ExecContext(ctx,
		`UPDATE users SET last_login_at = $1, updated_at = $1 WHERE id = $2`,
		now, userID,
	)
	return err
}
