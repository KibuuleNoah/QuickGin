package controllers

import (
	"errors"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"

	appdb "yourmodule/db" // Replace with your actual module path
	"yourmodule/forms"
	"yourmodule/services"
)

// AuthController wires together OTP, mail, SMS, and token services.
type AuthController struct {
	userRepo *appdb.UserRepository
	otp      *services.OTPService
	mail     *services.MailService
	sms      *services.SMSService
	tokens   *services.TokenService
}

func NewAuthController(
	userRepo *appdb.UserRepository,
	otp *services.OTPService,
	mail *services.MailService,
	sms *services.SMSService,
	tokens *services.TokenService,
) *AuthController {
	return &AuthController{userRepo: userRepo, otp: otp, mail: mail, sms: sms, tokens: tokens}
}

// RegisterRoutes mounts all auth routes under the given RouterGroup.
func (a *AuthController) RegisterRoutes(rg *gin.RouterGroup, authMiddleware gin.HandlerFunc) {
	auth := rg.Group("/auth")
	{
		auth.POST("/request-otp", a.RequestOTP)
		auth.POST("/verify-otp", a.VerifyOTP)
		auth.POST("/refresh", a.Refresh)
		auth.POST("/logout", authMiddleware, a.Logout)
		auth.POST("/logout-all", authMiddleware, a.LogoutAll)
		auth.GET("/me", authMiddleware, a.Me)
	}
}

// Refresh godoc
// @Summary      Rotate refresh token
// @Description  Accepts a valid refresh token, revokes it, and issues a new access + refresh pair.
// @Tags         auth
// @Accept       json
// @Produce      json
// @Param        body  body      forms.RefreshForm  true  "refresh token"
// @Success      200   {object}  map[string]string
// @Router       /auth/refresh [post]
func (a *AuthController) Refresh(c *gin.Context) {
	var form forms.RefreshForm
	if err := c.ShouldBindJSON(&form); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	ctx := c.Request.Context()
	access, refresh, _, err := a.tokens.RotateRefreshToken(ctx, form.RefreshToken)
	if err != nil {
		switch {
		case errors.Is(err, services.ErrRefreshTokenNotFound),
			errors.Is(err, services.ErrRefreshTokenExpired):
			c.JSON(http.StatusUnauthorized, gin.H{"error": err.Error()})
		default:
			c.JSON(http.StatusInternalServerError, gin.H{"error": "could not refresh token"})
		}
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"token":         access,
		"refresh_token": refresh,
	})
}

// Logout godoc
// @Summary      Revoke current session
// @Description  Revokes the supplied refresh token, ending the current session.
// @Tags         auth
// @Accept       json
// @Produce      json
// @Security     BearerAuth
// @Param        body  body      forms.RefreshForm  true  "refresh token to revoke"
// @Success      204
// @Router       /auth/logout [post]
func (a *AuthController) Logout(c *gin.Context) {
	var form forms.RefreshForm
	if err := c.ShouldBindJSON(&form); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}
	if err := a.tokens.RevokeRefreshToken(c.Request.Context(), form.RefreshToken); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "logout failed"})
		return
	}
	c.Status(http.StatusNoContent)
}

// LogoutAll godoc
// @Summary      Revoke all sessions
// @Description  Revokes every refresh token for the authenticated user.
// @Tags         auth
// @Security     BearerAuth
// @Success      204
// @Router       /auth/logout-all [post]
func (a *AuthController) LogoutAll(c *gin.Context) {
	userID := c.GetString("userID")
	if err := a.tokens.RevokeAllUserTokens(c.Request.Context(), userID); err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "logout failed"})
		return
	}
	c.Status(http.StatusNoContent)
}

// Me godoc
// @Summary      Get current user
// @Description  Returns the authenticated user's profile.
// @Tags         auth
// @Produce      json
// @Security     BearerAuth
// @Success      200  {object}  models.User
// @Router       /auth/me [get]
func (a *AuthController) Me(c *gin.Context) {
	userID := c.GetString("userID")
	user, err := a.userRepo.FindByID(c.Request.Context(), userID)
	if err != nil || user == nil {
		c.JSON(http.StatusNotFound, gin.H{"error": "user not found"})
		return
	}
	c.JSON(http.StatusOK, gin.H{"record": user})
}
