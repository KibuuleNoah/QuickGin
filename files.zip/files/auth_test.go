package tests

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/gin-gonic/gin"
	"github.com/redis/go-redis/v9"

	"yourmodule/controllers" // Replace with your module path
	appdb "yourmodule/db"
	"yourmodule/middleware"
	"yourmodule/services"
)

// setupTestRouter wires up the auth routes against test doubles.
// Callers own the returned captureOTP channel — every generated OTP is sent to it.
func setupTestRouter(t *testing.T, db testDB, rdb *redis.Client) (*gin.Engine, chan string) {
	t.Helper()
	gin.SetMode(gin.TestMode)

	otpCh := make(chan string, 4)

	otpSvc := services.NewOTPService(rdb)

	// Stub mail — captures OTPs instead of actually sending email
	mailSvc := &stubMailService{ch: otpCh}
	smsSvc := &stubSMSService{ch: otpCh}

	tokenSvc := services.NewTokenService(services.TokenConfig{
		AccessSecret:  "test-access-secret-32byteslong!!!!",
		RefreshSecret: "test-refresh-secret-32byteslong!!!",
	}, db.sqlx)

	userRepo := appdb.NewUserRepository(db.sqlx)
	authCtrl := controllers.NewAuthController(userRepo, otpSvc, mailSvc, smsSvc, tokenSvc)
	authMW := middleware.AuthMiddleware(tokenSvc)

	r := gin.New()
	api := r.Group("/api")
	authCtrl.RegisterRoutes(api, authMW)
	return r, otpCh
}

// ── Full happy-path test: request OTP → verify → refresh → me ─────────────

func TestEmailOTPFlow(t *testing.T) {
	// NOTE: Replace testDB with your own test DB setup helper.
	// This test requires a running Postgres + Redis; skip in CI without them.
	t.Skip("integration test — requires Postgres + Redis")

	db := newTestDB(t)
	rdb := newTestRedis(t)
	r, otpCh := setupTestRouter(t, db, rdb)

	// 1. Request OTP
	body, _ := json.Marshal(map[string]string{"email": "alice@example.com"})
	w := httptest.NewRecorder()
	req, _ := http.NewRequest(http.MethodPost, "/api/auth/request-otp", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("request-otp: expected 200, got %d: %s", w.Code, w.Body)
	}

	otp := <-otpCh

	// 2. Verify OTP
	body, _ = json.Marshal(map[string]string{"email": "alice@example.com", "otp": otp})
	w = httptest.NewRecorder()
	req, _ = http.NewRequest(http.MethodPost, "/api/auth/verify-otp", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("verify-otp: expected 200, got %d: %s", w.Code, w.Body)
	}

	var authResp struct {
		Token        string `json:"token"`
		RefreshToken string `json:"refresh_token"`
	}
	json.Unmarshal(w.Body.Bytes(), &authResp)

	if authResp.Token == "" || authResp.RefreshToken == "" {
		t.Fatal("expected token and refresh_token in response")
	}

	// 3. /me with access token
	w = httptest.NewRecorder()
	req, _ = http.NewRequest(http.MethodGet, "/api/auth/me", nil)
	req.Header.Set("Authorization", "Bearer "+authResp.Token)
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("me: expected 200, got %d: %s", w.Code, w.Body)
	}

	// 4. Refresh
	body, _ = json.Marshal(map[string]string{"refresh_token": authResp.RefreshToken})
	w = httptest.NewRecorder()
	req, _ = http.NewRequest(http.MethodPost, "/api/auth/refresh", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusOK {
		t.Fatalf("refresh: expected 200, got %d: %s", w.Code, w.Body)
	}
}

func TestVerifyOTP_InvalidCode(t *testing.T) {
	t.Skip("integration test — requires Postgres + Redis")
	db := newTestDB(t)
	rdb := newTestRedis(t)
	r, _ := setupTestRouter(t, db, rdb)

	body, _ := json.Marshal(map[string]string{"email": "bob@example.com", "otp": "000000"})
	w := httptest.NewRecorder()
	req, _ := http.NewRequest(http.MethodPost, "/api/auth/verify-otp", bytes.NewBuffer(body))
	req.Header.Set("Content-Type", "application/json")
	r.ServeHTTP(w, req)

	if w.Code != http.StatusUnauthorized {
		t.Fatalf("expected 401 for invalid OTP, got %d", w.Code)
	}
}

// ── Stubs ────────────────────────────────────────────────────────────────────

type stubMailService struct{ ch chan string }

func (s *stubMailService) SendOTP(to, otp string) error {
	s.ch <- otp
	return nil
}

type stubSMSService struct{ ch chan string }

func (s *stubSMSService) SendOTP(to, otp string) error {
	s.ch <- otp
	return nil
}

// ── Helpers (replace with your own test DB / Redis helpers) ──────────────────

type testDB struct{ sqlx interface{ /* *sqlx.DB */ } }

func newTestDB(t *testing.T) testDB  { t.Helper(); return testDB{} }
func newTestRedis(t *testing.T) *redis.Client {
	t.Helper()
	rdb := redis.NewClient(&redis.Options{Addr: "localhost:6379", DB: 15})
	rdb.FlushDB(context.Background())
	return rdb
}
